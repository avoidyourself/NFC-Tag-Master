# RFID Tool - NFC Clone, Reader, Writer & Emulator

## Overview
Native Android application (Kotlin + Jetpack Compose) for NFC/RFID tag reading, writing, cloning, and emulation. Targets Android 16 (API 36), optimized for Google Pixel 9a.

## Architecture
- **Language**: Kotlin
- **UI Framework**: Jetpack Compose with Material 3
- **Build System**: Gradle (Kotlin DSL)
- **Database**: Room (local SQLite)
- **Navigation**: Jetpack Navigation Compose
- **State**: ViewModel + StateFlow
- **Min SDK**: 26 | **Target SDK**: 36

## Project Structure
```
app/
  build.gradle.kts              # App module build config
  proguard-rules.pro            # ProGuard rules
  src/main/
    AndroidManifest.xml         # App manifest with NFC permissions
    java/com/rfidtool/
      MainActivity.kt           # Main activity with NFC foreground dispatch
      RFIDToolApp.kt            # Application class
      data/
        AppDatabase.kt          # Room database
        NfcTagEntity.kt         # Tag data entity
        TagDao.kt               # Database access object
      nfc/
        NfcManager.kt           # NFC read/write/wipe operations
        HceService.kt           # Host Card Emulation service
      viewmodel/
        MainViewModel.kt        # Central ViewModel for all screens
      ui/
        theme/
          Color.kt              # Color palette (dark cyberpunk theme)
          Theme.kt              # Material 3 theme setup
          Type.kt               # Typography
        navigation/
          AppNavigation.kt      # Bottom nav + routes
        screens/
          ReaderScreen.kt       # NFC tag scanning screen
          WriterScreen.kt       # NDEF/Raw/Clone/Wipe write modes
          EmulatorScreen.kt     # HCE tag emulation & reader mode
          SavedScreen.kt        # Tag library with search & filters
          TagDetailScreen.kt    # Full tag details, dump, analysis
        components/
          ScanAnimation.kt      # Animated scanning rings
          TagCard.kt             # Tag list item card
    res/
      values/                   # Colors, strings, themes
      xml/                      # NFC tech filter, HCE service config
      drawable/                 # Adaptive icon foreground
      mipmap-anydpi-v26/        # Adaptive icon launcher

build.gradle.kts                # Root build file
settings.gradle.kts             # Project settings
gradle.properties               # Gradle config
```

## Key Features
- **Reader**: Real NFC tag scanning with full data extraction (UID, ATQA, SAK, NDEF, raw dump)
- **Writer**: NDEF text write, raw hex write, clone from saved tag, wipe/zero tag
- **Emulator**: HCE-based tag emulation, reader mode for tag detection
- **Saved Tags**: Room database persistence, search, filter by type/protection
- **Tag Detail**: Full analysis, editable name, hex dump viewer, emulate/delete actions

## NFC Technologies Supported
- NfcA, NfcB, NfcF, NfcV
- MIFARE Classic (1K/4K), MIFARE Ultralight
- NTAG213/215/216
- ISO 14443-4 (IsoDep)
- NDEF read/write
- NdefFormatable

## Build Instructions
1. Open in Android Studio or use command line
2. `./gradlew assembleDebug` for debug APK
3. `./gradlew assembleRelease` for release APK
4. APK output: `app/build/outputs/apk/`

## Design
- Dark cyberpunk theme: deep navy background (#050A14), electric cyan accent (#00D4FF)
- Purple secondary (#7C3AED) for writer operations
- Monospace font for hex/UID displays
- Animated scan rings, pulsing status indicators
