package com.rfidtool.ui.theme

import androidx.compose.ui.graphics.Color

val Background = Color(0xFF050A14)
val Surface = Color(0xFF0D1525)
val SurfaceElevated = Color(0xFF111D30)
val SurfaceBorder = Color(0xFF1A2844)
val Accent = Color(0xFF00D4FF)
val AccentDim = Color(0xFF0099BB)
val Purple = Color(0xFF7C3AED)
val TextPrimary = Color(0xFFE8F4FF)
val TextSecondary = Color(0xFF6B8CAE)
val TextMuted = Color(0xFF3A5068)
val Success = Color(0xFF10B981)
val Warning = Color(0xFFF59E0B)
val Error = Color(0xFFEF4444)

val TagColors = listOf(
    Color(0xFF00D4FF),
    Color(0xFF7C3AED),
    Color(0xFF10B981),
    Color(0xFFF59E0B),
    Color(0xFFEF4444),
    Color(0xFFEC4899),
    Color(0xFF06B6D4),
    Color(0xFF84CC16),
)
