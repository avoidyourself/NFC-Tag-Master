package com.rfidtool.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.outlined.LibraryBooks
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rfidtool.ui.components.TagCard
import com.rfidtool.ui.theme.*
import com.rfidtool.viewmodel.MainViewModel

private val FILTERS = listOf("ALL", "MIFARE", "NTAG", "ISO", "PROTECTED")

@Composable
fun SavedScreen(
    viewModel: MainViewModel,
    onTagClick: (String) -> Unit,
) {
    val savedTags by viewModel.savedTags.collectAsState()
    var search by remember { mutableStateOf("") }
    var activeFilter by remember { mutableStateOf("ALL") }

    val filtered = savedTags.filter { tag ->
        val matchSearch = search.isBlank() ||
                tag.name.contains(search, ignoreCase = true) ||
                tag.uid.contains(search, ignoreCase = true) ||
                tag.tagType.contains(search, ignoreCase = true)

        val matchFilter = when (activeFilter) {
            "ALL" -> true
            "MIFARE" -> tag.tagType.contains("MIFARE", ignoreCase = true)
            "NTAG" -> tag.tagType.contains("NTAG", ignoreCase = true)
            "ISO" -> tag.tagType.contains("ISO", ignoreCase = true)
            "PROTECTED" -> tag.isProtected
            else -> true
        }

        matchSearch && matchFilter
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Background),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column {
                Text("SAVED TAGS", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = TextPrimary, letterSpacing = 3.sp)
                Text(
                    "${savedTags.size} tag${if (savedTags.size != 1) "s" else ""} in library",
                    fontSize = 13.sp,
                    color = TextMuted,
                )
            }
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Accent.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    "${filtered.size}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Accent,
                )
            }
        }

        HorizontalDivider(color = SurfaceBorder, thickness = 1.dp)

        OutlinedTextField(
            value = search,
            onValueChange = { search = it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            placeholder = { Text("Search by name, UID, type...", color = TextMuted) },
            leadingIcon = { Icon(Icons.Outlined.Search, null, tint = TextMuted, modifier = Modifier.size(18.dp)) },
            trailingIcon = {
                if (search.isNotEmpty()) {
                    IconButton(onClick = { search = "" }) {
                        Icon(Icons.Filled.Close, null, tint = TextMuted, modifier = Modifier.size(16.dp))
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(10.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Accent,
                unfocusedBorderColor = SurfaceBorder,
                focusedContainerColor = Surface,
                unfocusedContainerColor = Surface,
                cursorColor = Accent,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary,
            ),
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            FILTERS.forEach { filter ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (activeFilter == filter) Accent.copy(alpha = 0.15f) else Surface)
                        .clickable { activeFilter = filter }
                        .padding(horizontal = 10.dp, vertical = 5.dp),
                ) {
                    Text(
                        filter,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (activeFilter == filter) Accent else TextMuted,
                        letterSpacing = 1.sp,
                    )
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        if (filtered.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(top = 60.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Icon(Icons.Outlined.LibraryBooks, null, tint = TextMuted, modifier = Modifier.size(48.dp))
                Text(
                    if (savedTags.isEmpty()) "No saved tags" else "No matches found",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextSecondary,
                )
                Text(
                    if (savedTags.isEmpty()) "Scan NFC tags in the Reader tab and save them here."
                    else "Try adjusting your search or filter.",
                    fontSize = 14.sp,
                    color = TextMuted,
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items(filtered, key = { it.id }) { tag ->
                    TagCard(
                        tag = tag,
                        onClick = { onTagClick(tag.id) },
                        onDelete = { viewModel.deleteTag(tag.id) },
                    )
                }
                item { Spacer(Modifier.height(80.dp)) }
            }
        }
    }
}
