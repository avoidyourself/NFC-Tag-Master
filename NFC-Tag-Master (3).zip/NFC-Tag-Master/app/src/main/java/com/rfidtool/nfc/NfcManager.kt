package com.rfidtool.nfc

import android.app.Activity
import android.content.Intent
import android.nfc.NdefMessage
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.IsoDep
import android.nfc.tech.MifareClassic
import android.nfc.tech.MifareUltralight
import android.nfc.tech.Ndef
import android.nfc.tech.NdefFormatable
import android.nfc.tech.NfcA
import android.nfc.tech.NfcB
import android.nfc.tech.NfcF
import android.nfc.tech.NfcV
import android.os.Bundle
import android.util.Log
import com.rfidtool.data.NfcTagEntity
import com.rfidtool.ui.theme.TagColors
import java.util.UUID

data class ScannedTagData(
    val uid: String,
    val tagType: String,
    val techList: List<String>,
    val atqa: String,
    val sak: String,
    val maxTransceiveLength: Int,
    val memorySize: Int,
    val ndefPayload: String?,
    val rawDump: List<String>,
    val isProtected: Boolean,
)

class NfcManager {

    companion object {
        private const val TAG = "NfcManager"

        fun isNfcAvailable(activity: Activity): Boolean {
            val adapter = NfcAdapter.getDefaultAdapter(activity)
            return adapter != null
        }

        fun isNfcEnabled(activity: Activity): Boolean {
            val adapter = NfcAdapter.getDefaultAdapter(activity)
            return adapter?.isEnabled == true
        }

        fun enableForegroundDispatch(activity: Activity, intent: android.app.PendingIntent) {
            val adapter = NfcAdapter.getDefaultAdapter(activity) ?: return
            val filters = arrayOf(
                android.content.IntentFilter(NfcAdapter.ACTION_NDEF_DISCOVERED),
                android.content.IntentFilter(NfcAdapter.ACTION_TECH_DISCOVERED),
                android.content.IntentFilter(NfcAdapter.ACTION_TAG_DISCOVERED),
            )
            val techLists = arrayOf(
                arrayOf(NfcA::class.java.name),
                arrayOf(NfcB::class.java.name),
                arrayOf(MifareClassic::class.java.name),
                arrayOf(MifareUltralight::class.java.name),
                arrayOf(Ndef::class.java.name),
                arrayOf(IsoDep::class.java.name),
            )
            adapter.enableForegroundDispatch(activity, intent, filters, techLists)
        }

        fun disableForegroundDispatch(activity: Activity) {
            val adapter = NfcAdapter.getDefaultAdapter(activity) ?: return
            adapter.disableForegroundDispatch(activity)
        }

        fun parseTag(intent: Intent): ScannedTagData? {
            val tag = intent.getParcelableExtra<Tag>(NfcAdapter.EXTRA_TAG) ?: return null
            return parseTag(tag)
        }

        fun parseTag(tag: Tag): ScannedTagData {
            val uid = tag.id.joinToString(":") { "%02X".format(it) }
            val techList = tag.techList.map { it.substringAfterLast(".") }

            var atqa = ""
            var sak = ""
            var maxTransceive = 0
            var memorySize = 0
            var tagType = "Unknown"
            var isProtected = false
            val rawDump = mutableListOf<String>()
            var ndefPayload: String? = null

            try {
                val nfcA = NfcA.get(tag)
                if (nfcA != null) {
                    nfcA.connect()
                    atqa = nfcA.atqa.joinToString(":") { "%02X".format(it) }
                    sak = "%02X".format(nfcA.sak.toInt())
                    maxTransceive = nfcA.maxTransceiveLength
                    nfcA.close()
                }
            } catch (e: Exception) {
                Log.w(TAG, "NfcA read error: ${e.message}")
            }

            try {
                val mifareClassic = MifareClassic.get(tag)
                if (mifareClassic != null) {
                    mifareClassic.connect()
                    memorySize = mifareClassic.size
                    tagType = when (mifareClassic.type) {
                        MifareClassic.TYPE_CLASSIC -> "MIFARE Classic ${memorySize / 1024}K"
                        MifareClassic.TYPE_PLUS -> "MIFARE Plus"
                        MifareClassic.TYPE_PRO -> "MIFARE Pro"
                        else -> "MIFARE Classic"
                    }
                    for (sector in 0 until mifareClassic.sectorCount) {
                        val authenticated = mifareClassic.authenticateSectorWithKeyA(
                            sector, MifareClassic.KEY_DEFAULT
                        )
                        if (authenticated) {
                            val firstBlock = mifareClassic.sectorToBlock(sector)
                            val blockCount = mifareClassic.getBlockCountInSector(sector)
                            val sectorHex = StringBuilder("[S%02d] ".format(sector))
                            for (block in firstBlock until firstBlock + blockCount) {
                                try {
                                    val data = mifareClassic.readBlock(block)
                                    sectorHex.append(data.joinToString(" ") { "%02X".format(it) })
                                    sectorHex.append(" | ")
                                } catch (e: Exception) {
                                    sectorHex.append("?? " .repeat(16))
                                    sectorHex.append("| ")
                                }
                            }
                            rawDump.add(sectorHex.toString().trimEnd(' ', '|'))
                        } else {
                            isProtected = true
                            rawDump.add("[S%02d] ** LOCKED ** (authentication failed)".format(sector))
                        }
                    }
                    mifareClassic.close()
                }
            } catch (e: Exception) {
                Log.w(TAG, "MifareClassic read error: ${e.message}")
            }

            try {
                val mifareUL = MifareUltralight.get(tag)
                if (mifareUL != null) {
                    mifareUL.connect()
                    tagType = when (mifareUL.type) {
                        MifareUltralight.TYPE_ULTRALIGHT -> "MIFARE Ultralight"
                        MifareUltralight.TYPE_ULTRALIGHT_C -> "MIFARE Ultralight C"
                        else -> "MIFARE Ultralight"
                    }
                    var page = 0
                    while (page < 44) {
                        try {
                            val data = mifareUL.readPages(page)
                            memorySize += data.size
                            val hex = data.joinToString(" ") { "%02X".format(it) }
                            rawDump.add("[P%02d-%02d] %s".format(page, page + 3, hex))
                            page += 4
                        } catch (e: Exception) {
                            break
                        }
                    }
                    mifareUL.close()
                }
            } catch (e: Exception) {
                Log.w(TAG, "MifareUltralight read error: ${e.message}")
            }

            try {
                val ndef = Ndef.get(tag)
                if (ndef != null) {
                    ndef.connect()
                    memorySize = ndef.maxSize
                    if (tagType == "Unknown") {
                        tagType = when {
                            ndef.type.contains("1") -> "NTAG213"
                            ndef.type.contains("2") -> "NTAG215"
                            ndef.type.contains("4") -> "NTAG216"
                            else -> ndef.type
                        }
                    }
                    val ndefMessage = ndef.ndefMessage
                    if (ndefMessage != null) {
                        val records = ndefMessage.records
                        for (record in records) {
                            val payload = record.payload
                            if (payload.isNotEmpty()) {
                                val langCodeLen = payload[0].toInt() and 0x3F
                                if (payload.size > langCodeLen + 1) {
                                    val lang = String(payload, 1, langCodeLen, Charsets.US_ASCII)
                                    val text = String(payload, langCodeLen + 1, payload.size - langCodeLen - 1, Charsets.UTF_8)
                                    ndefPayload = "$lang:$text"
                                } else {
                                    ndefPayload = payload.joinToString(" ") { "%02X".format(it) }
                                }
                            }
                        }
                    }
                    isProtected = !ndef.isWritable
                    ndef.close()
                }
            } catch (e: Exception) {
                Log.w(TAG, "Ndef read error: ${e.message}")
            }

            try {
                val isoDep = IsoDep.get(tag)
                if (isoDep != null && tagType == "Unknown") {
                    tagType = "ISO 14443-4"
                    maxTransceive = isoDep.maxTransceiveLength
                }
            } catch (e: Exception) {
                Log.w(TAG, "IsoDep read error: ${e.message}")
            }

            if (rawDump.isEmpty()) {
                rawDump.add("[No raw data available]")
            }

            return ScannedTagData(
                uid = uid,
                tagType = tagType,
                techList = techList,
                atqa = atqa,
                sak = sak,
                maxTransceiveLength = maxTransceive,
                memorySize = memorySize,
                ndefPayload = ndefPayload,
                rawDump = rawDump,
                isProtected = isProtected,
            )
        }

        fun scannedDataToEntity(data: ScannedTagData): NfcTagEntity {
            return NfcTagEntity(
                id = UUID.randomUUID().toString(),
                name = "Tag ${data.uid.take(8)}",
                uid = data.uid,
                tagType = data.tagType,
                techList = data.techList.joinToString(","),
                atqa = data.atqa,
                sak = data.sak,
                maxTransceiveLength = data.maxTransceiveLength,
                memorySize = data.memorySize,
                ndefPayload = data.ndefPayload,
                rawDump = data.rawDump.joinToString("\n"),
                scannedAt = System.currentTimeMillis(),
                colorIndex = (Math.random() * TagColors.size).toInt(),
                isProtected = data.isProtected,
            )
        }

        fun writeNdefText(tag: Tag, text: String, languageCode: String = "en"): Boolean {
            return try {
                val langBytes = languageCode.toByteArray(Charsets.US_ASCII)
                val textBytes = text.toByteArray(Charsets.UTF_8)
                val payload = ByteArray(1 + langBytes.size + textBytes.size)
                payload[0] = langBytes.size.toByte()
                System.arraycopy(langBytes, 0, payload, 1, langBytes.size)
                System.arraycopy(textBytes, 0, payload, 1 + langBytes.size, textBytes.size)

                val record = android.nfc.NdefRecord(
                    android.nfc.NdefRecord.TNF_WELL_KNOWN,
                    android.nfc.NdefRecord.RTD_TEXT,
                    ByteArray(0),
                    payload
                )
                val message = NdefMessage(arrayOf(record))

                val ndef = Ndef.get(tag)
                if (ndef != null) {
                    ndef.connect()
                    if (ndef.isWritable) {
                        ndef.writeNdefMessage(message)
                        ndef.close()
                        true
                    } else {
                        ndef.close()
                        false
                    }
                } else {
                    val formatable = NdefFormatable.get(tag)
                    if (formatable != null) {
                        formatable.connect()
                        formatable.format(message)
                        formatable.close()
                        true
                    } else {
                        false
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Write error: ${e.message}")
                false
            }
        }

        fun wipeTag(tag: Tag): Boolean {
            return try {
                val mifareClassic = MifareClassic.get(tag)
                if (mifareClassic != null) {
                    mifareClassic.connect()
                    val zeros = ByteArray(16) { 0x00 }
                    for (sector in 1 until mifareClassic.sectorCount) {
                        val authed = mifareClassic.authenticateSectorWithKeyA(
                            sector, MifareClassic.KEY_DEFAULT
                        )
                        if (authed) {
                            val firstBlock = mifareClassic.sectorToBlock(sector)
                            val blockCount = mifareClassic.getBlockCountInSector(sector)
                            for (block in firstBlock until firstBlock + blockCount - 1) {
                                try {
                                    mifareClassic.writeBlock(block, zeros)
                                } catch (_: Exception) {}
                            }
                        }
                    }
                    mifareClassic.close()
                    return true
                }

                val mifareUL = MifareUltralight.get(tag)
                if (mifareUL != null) {
                    mifareUL.connect()
                    val zeros = ByteArray(4) { 0x00 }
                    for (page in 4..39) {
                        try {
                            mifareUL.writePage(page, zeros)
                        } catch (_: Exception) { break }
                    }
                    mifareUL.close()
                    return true
                }

                false
            } catch (e: Exception) {
                Log.e(TAG, "Wipe error: ${e.message}")
                false
            }
        }
    }
}
