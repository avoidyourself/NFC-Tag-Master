package com.rfidtool.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface TagDao {
    @Query("SELECT * FROM nfc_tags ORDER BY scannedAt DESC")
    fun getAllTags(): Flow<List<NfcTagEntity>>

    @Query("SELECT * FROM nfc_tags WHERE id = :id")
    suspend fun getTagById(id: String): NfcTagEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTag(tag: NfcTagEntity)

    @Update
    suspend fun updateTag(tag: NfcTagEntity)

    @Delete
    suspend fun deleteTag(tag: NfcTagEntity)

    @Query("DELETE FROM nfc_tags WHERE id = :id")
    suspend fun deleteTagById(id: String)

    @Query("SELECT * FROM nfc_tags WHERE name LIKE '%' || :query || '%' OR uid LIKE '%' || :query || '%' OR tagType LIKE '%' || :query || '%' ORDER BY scannedAt DESC")
    fun searchTags(query: String): Flow<List<NfcTagEntity>>
}
