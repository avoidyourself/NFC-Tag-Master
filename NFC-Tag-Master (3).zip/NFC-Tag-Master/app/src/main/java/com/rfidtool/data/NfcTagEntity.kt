package com.rfidtool.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "nfc_tags")
data class NfcTagEntity(
    @PrimaryKey
    val id: String,
    val name: String,
    val uid: String,
    val tagType: String,
    val techList: String,
    val atqa: String,
    val sak: String,
    val maxTransceiveLength: Int,
    val memorySize: Int,
    val ndefPayload: String?,
    val rawDump: String,
    val scannedAt: Long,
    val colorIndex: Int,
    val isProtected: Boolean,
)
