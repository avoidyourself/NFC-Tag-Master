package com.rfidtool.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rfidtool.ui.components.ScanAnimation
import com.rfidtool.ui.theme.*
import com.rfidtool.viewmodel.MainViewModel
import com.rfidtool.viewmodel.ScanState

@Composable
fun ReaderScreen(viewModel: MainViewModel) {
    val state by viewModel.readerState.collectAsState()
    val scrollState = rememberScrollState()

    val statusColor = when (state.scanState) {
        ScanState.FOUND -> Success
        ScanState.ERROR -> Error
        else -> Accent
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Background),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column {
                Text(
                    "NFC READER",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    letterSpacing = 3.sp,
                )
                Text(
                    "Hold device near tag",
                    fontSize = 13.sp,
                    color = TextMuted,
                )
            }
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(statusColor)
            )
        }

        HorizontalDivider(color = SurfaceBorder, thickness = 1.dp)

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.height(16.dp))

            ScanAnimation(
                isScanning = state.scanState == ScanState.SCANNING,
                isFound = state.scanState == ScanState.FOUND,
                isError = state.scanState == ScanState.ERROR,
                color = statusColor,
            )

            Spacer(Modifier.height(12.dp))

            Text(
                text = when (state.scanState) {
                    ScanState.IDLE -> "READY TO SCAN"
                    ScanState.SCANNING -> "SCANNING..."
                    ScanState.FOUND -> "TAG DETECTED"
                    ScanState.ERROR -> "SCAN ERROR"
                },
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = statusColor,
                letterSpacing = 3.sp,
            )

            Spacer(Modifier.height(20.dp))

            when (state.scanState) {
                ScanState.IDLE, ScanState.ERROR -> {
                    if (state.errorMessage != null) {
                        Text(
                            state.errorMessage!!,
                            fontSize = 13.sp,
                            color = Error,
                            modifier = Modifier.padding(bottom = 12.dp),
                        )
                    }
                    Button(
                        onClick = { viewModel.startScanning() },
                        colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Background),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.height(48.dp),
                    ) {
                        Text(
                            "START SCAN",
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 3.sp,
                        )
                    }
                }
                ScanState.SCANNING -> {
                    Text("Searching for NFC tags...", fontSize = 14.sp, color = TextSecondary)
                    Text("Keep device steady and close to tag", fontSize = 12.sp, color = TextMuted)
                }
                ScanState.FOUND -> {}
            }

            AnimatedVisibility(
                visible = state.scanState == ScanState.FOUND && state.currentTag != null,
                enter = fadeIn() + slideInVertically { it / 3 },
            ) {
                val tag = state.currentTag ?: return@AnimatedVisibility
                val entity = state.currentEntity

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Surface)
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Text(
                            entity?.name ?: "Tag",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            modifier = Modifier.weight(1f),
                        )
                        Button(
                            onClick = { viewModel.saveCurrentTag() },
                            enabled = !state.isSaved,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (state.isSaved) Success.copy(alpha = 0.15f) else Accent.copy(alpha = 0.15f),
                                contentColor = if (state.isSaved) Success else Accent,
                            ),
                            shape = RoundedCornerShape(6.dp),
                        ) {
                            Icon(
                                if (state.isSaved) Icons.Filled.Check else Icons.Outlined.BookmarkBorder,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp),
                            )
                            Text(
                                if (state.isSaved) "SAVED" else "SAVE",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                letterSpacing = 1.5.sp,
                                modifier = Modifier.padding(start = 4.dp),
                            )
                        }
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Surface)
                            .padding(14.dp),
                    ) {
                        SectionLabel("TAG INFORMATION")
                        DataRow("UID", tag.uid, mono = true)
                        DataRow("Type", tag.tagType)
                        DataRow("Technology", tag.techList.joinToString(", "))
                        DataRow("ATQA", tag.atqa, mono = true)
                        DataRow("SAK", tag.sak, mono = true)
                        DataRow("Memory", "${tag.memorySize} bytes")
                        DataRow("Protected", if (tag.isProtected) "Yes" else "No")
                    }

                    if (tag.ndefPayload != null) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Surface)
                                .padding(14.dp),
                        ) {
                            SectionLabel("NDEF DATA")
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(SurfaceElevated)
                                    .padding(10.dp)
                            ) {
                                Text(
                                    tag.ndefPayload,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 13.sp,
                                    color = Accent,
                                )
                            }
                        }
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Surface)
                            .padding(14.dp),
                    ) {
                        SectionLabel("RAW DUMP (first 4 sectors)")
                        tag.rawDump.take(4).forEach { line ->
                            Text(
                                line,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                color = TextSecondary,
                                modifier = Modifier.padding(vertical = 2.dp),
                            )
                        }
                    }

                    OutlinedButton(
                        onClick = { viewModel.resetReader() },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextSecondary),
                    ) {
                        Icon(Icons.Outlined.Refresh, null, modifier = Modifier.size(16.dp))
                        Text(
                            "SCAN AGAIN",
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 2.sp,
                            modifier = Modifier.padding(start = 6.dp),
                        )
                    }

                    Spacer(Modifier.height(80.dp))
                }
            }
        }
    }
}

@Composable
fun SectionLabel(text: String) {
    Text(
        text,
        fontSize = 10.sp,
        fontWeight = FontWeight.Bold,
        color = TextMuted,
        letterSpacing = 2.sp,
        modifier = Modifier.padding(bottom = 8.dp),
    )
}

@Composable
fun DataRow(label: String, value: String, mono: Boolean = false) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(
            label,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            color = TextSecondary,
        )
        Text(
            value,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            color = TextPrimary,
            fontFamily = if (mono) FontFamily.Monospace else FontFamily.Default,
        )
    }
    HorizontalDivider(color = SurfaceBorder, thickness = 0.5.dp)
}
