package com.rfidtool.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.KeyboardArrowUp
import androidx.compose.material.icons.outlined.Sensors
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rfidtool.ui.theme.*
import com.rfidtool.viewmodel.EmulatorMode
import com.rfidtool.viewmodel.MainViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TagDetailScreen(
    tagId: String,
    viewModel: MainViewModel,
    onBack: () -> Unit,
    onEmulate: () -> Unit,
) {
    val savedTags by viewModel.savedTags.collectAsState()
    val tag = savedTags.find { it.id == tagId }

    if (tag == null) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Background),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Text("Tag not found", fontSize = 16.sp, color = TextMuted)
            Spacer(Modifier.height(12.dp))
            Button(onClick = onBack, colors = ButtonDefaults.buttonColors(containerColor = Surface)) {
                Text("Go Back", color = Accent)
            }
        }
        return
    }

    val tagColor = TagColors.getOrElse(tag.colorIndex) { Accent }
    var isEditingName by remember { mutableStateOf(false) }
    var nameInput by remember(tag.name) { mutableStateOf(tag.name) }
    var showDump by remember { mutableStateOf(false) }
    val rawDumpLines = tag.rawDump.split("\n")
    val dateFormat = SimpleDateFormat("MMM d, yyyy h:mm a", Locale.getDefault())

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Background),
    ) {
        TopAppBar(
            title = { Text("Tag Details", color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.SemiBold) },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Accent)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = Surface),
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Surface)
                    .padding(top = 3.dp),
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.dp)
                        .background(tagColor)
                )
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Box(modifier = Modifier.size(14.dp).clip(CircleShape).background(tagColor))
                        Column(modifier = Modifier.weight(1f)) {
                            if (isEditingName) {
                                OutlinedTextField(
                                    value = nameInput,
                                    onValueChange = { nameInput = it },
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = true,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = Accent,
                                        unfocusedBorderColor = SurfaceBorder,
                                        cursorColor = Accent,
                                        focusedTextColor = TextPrimary,
                                        unfocusedTextColor = TextPrimary,
                                    ),
                                    shape = RoundedCornerShape(8.dp),
                                    trailingIcon = {
                                        IconButton(onClick = {
                                            if (nameInput.isNotBlank()) {
                                                viewModel.updateTagName(tag.id, nameInput.trim())
                                            }
                                            isEditingName = false
                                        }) {
                                            Icon(Icons.Filled.CheckCircle, null, tint = Success)
                                        }
                                    },
                                )
                            } else {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.clickable { isEditingName = true },
                                ) {
                                    Text(
                                        tag.name,
                                        fontSize = 22.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                    Icon(Icons.Filled.Edit, null, tint = TextMuted, modifier = Modifier.size(14.dp))
                                }
                            }
                            Text(tag.tagType, fontSize = 13.sp, color = TextSecondary)
                        }
                        if (tag.isProtected) {
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Warning.copy(alpha = 0.15f))
                                    .padding(horizontal = 8.dp, vertical = 4.dp),
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Icon(Icons.Filled.Lock, null, tint = Warning, modifier = Modifier.size(12.dp))
                                Text("LOCKED", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Warning, letterSpacing = 1.sp)
                            }
                        }
                    }
                    Text(
                        tag.uid,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 18.sp,
                        color = tagColor,
                        letterSpacing = 2.sp,
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                OutlinedButton(
                    onClick = {
                        viewModel.setEmulatedTag(tag)
                        viewModel.setEmulatorMode(EmulatorMode.TAG)
                        onEmulate()
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Accent),
                ) {
                    Icon(Icons.Outlined.Sensors, null, modifier = Modifier.size(18.dp))
                    Text("EMULATE", fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp, modifier = Modifier.padding(start = 6.dp))
                }
                OutlinedButton(
                    onClick = {
                        viewModel.deleteTag(tag.id)
                        onBack()
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Error),
                ) {
                    Icon(Icons.Filled.Delete, null, modifier = Modifier.size(18.dp))
                    Text("DELETE", fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp, modifier = Modifier.padding(start = 6.dp))
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Surface)
                    .padding(14.dp),
            ) {
                SectionLabel("TAG INFORMATION")
                DataRow("UID", tag.uid, mono = true)
                DataRow("Tag Type", tag.tagType)
                DataRow("Technologies", tag.techList.replace(",", ", "))
                DataRow("ATQA", tag.atqa, mono = true)
                DataRow("SAK", tag.sak, mono = true)
                DataRow("Memory Size", "${tag.memorySize} bytes (${String.format("%.2f", tag.memorySize / 1024.0)} KB)")
                DataRow("Max Transceive", "${tag.maxTransceiveLength} bytes")
                DataRow("Protected", if (tag.isProtected) "Yes" else "No")
                DataRow("Scanned At", dateFormat.format(Date(tag.scannedAt)))
            }

            if (tag.ndefPayload != null) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Surface)
                        .padding(14.dp),
                ) {
                    SectionLabel("NDEF RECORD")
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(SurfaceElevated)
                            .padding(10.dp)
                    ) {
                        Text(
                            tag.ndefPayload,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 13.sp,
                            color = Accent,
                        )
                    }
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Surface)
                    .padding(14.dp),
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showDump = !showDump },
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("RAW MEMORY DUMP", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TextMuted, letterSpacing = 2.sp)
                    Icon(
                        if (showDump) Icons.Outlined.KeyboardArrowUp else Icons.Outlined.KeyboardArrowDown,
                        null, tint = TextMuted, modifier = Modifier.size(14.dp),
                    )
                }
                Spacer(Modifier.height(8.dp))
                AnimatedVisibility(showDump) {
                    Column {
                        rawDumpLines.forEach { line ->
                            Text(
                                line,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 9.sp,
                                color = TextSecondary,
                                modifier = Modifier.padding(vertical = 1.dp),
                            )
                        }
                    }
                }
                if (!showDump) {
                    Text("${rawDumpLines.size} sectors - tap to expand", fontSize = 12.sp, color = TextMuted)
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Surface)
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                SectionLabel("ANALYSIS")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.CheckCircle, null, tint = Success, modifier = Modifier.size(14.dp))
                    Text("Valid UID format (${tag.uid.split(":").size} bytes)", fontSize = 13.sp, color = TextSecondary)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (tag.isProtected) Icons.Filled.Lock else Icons.Filled.LockOpen, null, tint = if (tag.isProtected) Warning else Success, modifier = Modifier.size(14.dp))
                    Text(
                        if (tag.isProtected) "Access bits locked" else "Writable sectors available",
                        fontSize = 13.sp, color = TextSecondary,
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Description, null, tint = if (tag.ndefPayload != null) Accent else TextMuted, modifier = Modifier.size(14.dp))
                    Text(
                        if (tag.ndefPayload != null) "NDEF message present" else "No NDEF message",
                        fontSize = 13.sp, color = TextSecondary,
                    )
                }
            }

            Spacer(Modifier.height(24.dp))
        }
    }
}
