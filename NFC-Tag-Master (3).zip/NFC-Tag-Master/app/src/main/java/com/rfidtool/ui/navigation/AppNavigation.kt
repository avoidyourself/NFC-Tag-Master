package com.rfidtool.ui.navigation

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LibraryBooks
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Create
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.outlined.LibraryBooks
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.Create
import androidx.compose.material.icons.outlined.Sensors
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.rfidtool.ui.screens.EmulatorScreen
import com.rfidtool.ui.screens.ReaderScreen
import com.rfidtool.ui.screens.SavedScreen
import com.rfidtool.ui.screens.TagDetailScreen
import com.rfidtool.ui.screens.WriterScreen
import com.rfidtool.ui.theme.*
import com.rfidtool.viewmodel.MainViewModel

sealed class Screen(val route: String, val label: String, val iconSelected: ImageVector, val iconDefault: ImageVector) {
    data object Reader : Screen("reader", "Reader", Icons.Filled.Sensors, Icons.Outlined.Sensors)
    data object Writer : Screen("writer", "Writer", Icons.Filled.Create, Icons.Outlined.Create)
    data object Emulator : Screen("emulator", "Emulator", Icons.Filled.Memory, Icons.Outlined.Memory)
    data object Saved : Screen("saved", "Saved", Icons.Filled.LibraryBooks, Icons.Outlined.LibraryBooks)
}

private val bottomNavItems = listOf(Screen.Reader, Screen.Writer, Screen.Emulator, Screen.Saved)

@Composable
fun AppNavigation(viewModel: MainViewModel) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination

    val showBottomBar = bottomNavItems.any { screen ->
        currentDestination?.hierarchy?.any { it.route == screen.route } == true
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = Background,
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(
                    containerColor = Surface,
                    contentColor = TextPrimary,
                    tonalElevation = 0.dp,
                ) {
                    bottomNavItems.forEach { screen ->
                        val selected = currentDestination?.hierarchy?.any { it.route == screen.route } == true
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                navController.navigate(screen.route) {
                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = {
                                Icon(
                                    imageVector = if (selected) screen.iconSelected else screen.iconDefault,
                                    contentDescription = screen.label,
                                )
                            },
                            label = {
                                Text(
                                    screen.label,
                                    fontSize = 11.sp,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                    letterSpacing = 0.5.sp,
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Accent,
                                selectedTextColor = Accent,
                                unselectedIconColor = TextMuted,
                                unselectedTextColor = TextMuted,
                                indicatorColor = Accent.copy(alpha = 0.12f),
                            ),
                        )
                    }
                }
            }
        },
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Reader.route,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Background),
        ) {
            composable(Screen.Reader.route) { ReaderScreen(viewModel) }
            composable(Screen.Writer.route) { WriterScreen(viewModel) }
            composable(Screen.Emulator.route) { EmulatorScreen(viewModel) }
            composable(Screen.Saved.route) {
                SavedScreen(
                    viewModel = viewModel,
                    onTagClick = { tagId ->
                        navController.navigate("tag_detail/$tagId")
                    },
                )
            }
            composable(
                route = "tag_detail/{tagId}",
                arguments = listOf(navArgument("tagId") { type = NavType.StringType }),
            ) { backStackEntry ->
                val tagId = backStackEntry.arguments?.getString("tagId") ?: ""
                TagDetailScreen(
                    tagId = tagId,
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() },
                    onEmulate = {
                        navController.navigate(Screen.Emulator.route) {
                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                            launchSingleTop = true
                        }
                    },
                )
            }
        }
    }
}
