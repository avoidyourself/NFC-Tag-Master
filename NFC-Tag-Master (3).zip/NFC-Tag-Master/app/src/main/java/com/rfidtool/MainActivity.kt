package com.rfidtool

import android.app.PendingIntent
import android.content.Intent
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.rfidtool.nfc.NfcManager
import com.rfidtool.ui.navigation.AppNavigation
import com.rfidtool.ui.theme.RFIDToolTheme
import com.rfidtool.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()
    private var nfcPendingIntent: PendingIntent? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        if (!NfcManager.isNfcAvailable(this)) {
            Toast.makeText(this, "NFC is not available on this device", Toast.LENGTH_LONG).show()
        } else if (!NfcManager.isNfcEnabled(this)) {
            Toast.makeText(this, "Please enable NFC in Settings", Toast.LENGTH_LONG).show()
        }

        nfcPendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, javaClass).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_MUTABLE,
        )

        handleIntent(intent)

        setContent {
            RFIDToolTheme {
                AppNavigation(viewModel = viewModel)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        nfcPendingIntent?.let {
            NfcManager.enableForegroundDispatch(this, it)
        }
    }

    override fun onPause() {
        super.onPause()
        NfcManager.disableForegroundDispatch(this)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent) {
        when (intent.action) {
            NfcAdapter.ACTION_NDEF_DISCOVERED,
            NfcAdapter.ACTION_TECH_DISCOVERED,
            NfcAdapter.ACTION_TAG_DISCOVERED -> {
                val tag = intent.getParcelableExtra<Tag>(NfcAdapter.EXTRA_TAG)
                if (tag != null) {
                    viewModel.onTagDiscovered(tag)
                }
            }
        }
    }
}
