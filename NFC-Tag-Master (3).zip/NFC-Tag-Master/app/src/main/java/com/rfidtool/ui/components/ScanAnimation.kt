package com.rfidtool.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.outlined.Sensors
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Composable
fun ScanAnimation(
    isScanning: Boolean,
    isFound: Boolean = false,
    isError: Boolean = false,
    size: Dp = 200.dp,
    color: Color,
    modifier: Modifier = Modifier,
) {
    val infiniteTransition = rememberInfiniteTransition(label = "scan")

    val ring1 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = if (isScanning) 1f else 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart,
        ),
        label = "ring1",
    )

    val ring2 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = if (isScanning) 1f else 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, delayMillis = 600, easing = LinearEasing),
            repeatMode = RepeatMode.Restart,
        ),
        label = "ring2",
    )

    val ring3 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = if (isScanning) 1f else 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, delayMillis = 1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart,
        ),
        label = "ring3",
    )

    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(800),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "pulse",
    )

    Box(contentAlignment = Alignment.Center, modifier = modifier.size(size)) {
        if (isScanning) {
            Canvas(modifier = Modifier.size(size)) {
                val center = this.center
                val maxRadius = this.size.minDimension / 2f

                listOf(ring1, ring2, ring3).forEach { progress ->
                    val radius = maxRadius * (0.3f + progress * 0.7f)
                    val alpha = (1f - progress).coerceIn(0f, 0.6f)
                    drawCircle(
                        color = color.copy(alpha = alpha),
                        radius = radius,
                        center = center,
                        style = Stroke(width = 2f),
                    )
                }
            }
        }

        Canvas(modifier = Modifier.size(size * 0.4f * pulse)) {
            drawCircle(
                color = color.copy(alpha = 0.08f),
                radius = this.size.minDimension / 2f,
            )
            drawCircle(
                color = color,
                radius = this.size.minDimension / 2f,
                style = Stroke(width = 2.5f),
            )
        }

        Icon(
            imageVector = when {
                isFound -> Icons.Filled.CheckCircle
                isError -> Icons.Filled.Error
                else -> Icons.Outlined.Sensors
            },
            contentDescription = null,
            tint = color,
            modifier = Modifier.size(32.dp),
        )
    }
}
