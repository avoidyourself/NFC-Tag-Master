package com.rfidtool.nfc

import android.nfc.cardemulation.HostApduService
import android.os.Bundle
import android.util.Log

class HceService : HostApduService() {

    companion object {
        private const val TAG = "HceService"
        private val SELECT_APDU = byteArrayOf(
            0x00.toByte(), 0xA4.toByte(), 0x04.toByte(), 0x00.toByte(),
            0x07.toByte(),
            0xF0.toByte(), 0x01.toByte(), 0x02.toByte(), 0x03.toByte(),
            0x04.toByte(), 0x05.toByte(), 0x06.toByte()
        )
        private val SUCCESS_SW = byteArrayOf(0x90.toByte(), 0x00.toByte())
        private val UNKNOWN_CMD_SW = byteArrayOf(0x00.toByte(), 0x00.toByte())

        var emulatedUid: ByteArray? = null
        var emulatedData: ByteArray? = null
        var isActive = false
    }

    override fun processCommandApdu(commandApdu: ByteArray, extras: Bundle?): ByteArray {
        Log.d(TAG, "Received APDU: ${commandApdu.joinToString(" ") { "%02X".format(it) }}")

        if (commandApdu.size >= SELECT_APDU.size) {
            val header = commandApdu.copyOfRange(0, 5)
            val selectHeader = SELECT_APDU.copyOfRange(0, 5)
            if (header.contentEquals(selectHeader)) {
                Log.d(TAG, "SELECT command received, responding with data")
                val response = emulatedData ?: emulatedUid ?: byteArrayOf(0x00)
                return response + SUCCESS_SW
            }
        }

        if (commandApdu.size >= 2 && commandApdu[1] == 0xB0.toByte()) {
            Log.d(TAG, "READ BINARY command received")
            val data = emulatedData ?: emulatedUid ?: byteArrayOf(0x00)
            return data + SUCCESS_SW
        }

        return UNKNOWN_CMD_SW
    }

    override fun onDeactivated(reason: Int) {
        Log.d(TAG, "HCE deactivated, reason: $reason")
    }

    override fun onCreate() {
        super.onCreate()
        isActive = true
        Log.d(TAG, "HCE Service started")
    }

    override fun onDestroy() {
        super.onDestroy()
        isActive = false
        Log.d(TAG, "HCE Service stopped")
    }
}
