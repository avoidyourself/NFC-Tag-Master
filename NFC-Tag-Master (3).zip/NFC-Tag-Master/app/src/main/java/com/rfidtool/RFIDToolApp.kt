package com.rfidtool

import android.app.Application

class RFIDToolApp : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
