package com.rfidtool.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.KeyboardArrowUp
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.Sensors
import androidx.compose.material.icons.outlined.SettingsInputAntenna
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rfidtool.ui.theme.*
import com.rfidtool.viewmodel.EmulatorMode
import com.rfidtool.viewmodel.MainViewModel

@Composable
fun EmulatorScreen(viewModel: MainViewModel) {
    val state by viewModel.emulatorState.collectAsState()
    val savedTags by viewModel.savedTags.collectAsState()
    val scrollState = rememberScrollState()
    var showTagPicker by remember { mutableStateOf(false) }

    val isActive = state.mode != EmulatorMode.OFF
    val modeColor = when (state.mode) {
        EmulatorMode.TAG -> Accent
        EmulatorMode.READER -> Success
        EmulatorMode.OFF -> TextMuted
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Background),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column {
                Text("EMULATOR", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = TextPrimary, letterSpacing = 3.sp)
                Text("Tag & reader simulation", fontSize = 13.sp, color = TextMuted)
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                if (isActive) PulsingDot(modeColor)
                Text(
                    when (state.mode) {
                        EmulatorMode.OFF -> "OFFLINE"
                        EmulatorMode.TAG -> "TAG MODE"
                        EmulatorMode.READER -> "READER MODE"
                    },
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = modeColor,
                    letterSpacing = 1.5.sp,
                )
            }
        }

        HorizontalDivider(color = SurfaceBorder, thickness = 1.dp)

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Surface)
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                ) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(SurfaceElevated),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            Icons.Outlined.Memory,
                            contentDescription = null,
                            tint = if (isActive) modeColor else TextMuted,
                            modifier = Modifier.size(32.dp),
                        )
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.Bottom,
                    ) {
                        repeat(4) { i ->
                            val height = ((i + 1) * 8 + 8).dp
                            SignalBar(height, isActive, modeColor, i * 200)
                        }
                    }
                }

                Text(
                    when (state.mode) {
                        EmulatorMode.OFF -> "EMULATOR OFFLINE"
                        EmulatorMode.TAG -> "EMULATING NFC TAG"
                        EmulatorMode.READER -> "EMULATING NFC READER"
                    },
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isActive) modeColor else TextMuted,
                    letterSpacing = 2.sp,
                )

                Text(
                    when (state.mode) {
                        EmulatorMode.OFF -> "Select a mode below to start"
                        EmulatorMode.TAG -> state.emulatedTag?.let { "Broadcasting: ${it.name}" } ?: "No tag profile selected"
                        EmulatorMode.READER -> "Scanning for nearby tags"
                    },
                    fontSize = 13.sp,
                    color = TextSecondary,
                )
            }

            SectionLabel("SELECT MODE")

            ModeCard(
                title = "Emulate NFC Tag",
                description = "Your device broadcasts as an NFC/RFID tag. Readers will detect your device as a real card.",
                icon = Icons.Outlined.Sensors,
                color = Accent,
                isActive = state.mode == EmulatorMode.TAG,
                onToggle = {
                    viewModel.setEmulatorMode(
                        if (state.mode == EmulatorMode.TAG) EmulatorMode.OFF else EmulatorMode.TAG
                    )
                },
            )

            AnimatedVisibility(state.mode == EmulatorMode.TAG) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Surface)
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    SectionLabel("TAG PROFILE")
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(SurfaceElevated)
                            .clickable { showTagPicker = !showTagPicker }
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            state.emulatedTag?.name ?: "Select tag to emulate...",
                            fontSize = 14.sp,
                            color = TextPrimary,
                        )
                        Icon(
                            if (showTagPicker) Icons.Outlined.KeyboardArrowUp else Icons.Outlined.KeyboardArrowDown,
                            null, tint = TextMuted, modifier = Modifier.size(14.dp),
                        )
                    }
                    AnimatedVisibility(showTagPicker) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(SurfaceElevated),
                        ) {
                            if (savedTags.isEmpty()) {
                                Text("No saved tags", fontSize = 13.sp, color = TextMuted, modifier = Modifier.padding(12.dp))
                            } else {
                                savedTags.forEach { tag ->
                                    val tagColor = TagColors.getOrElse(tag.colorIndex) { Accent }
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                viewModel.setEmulatedTag(tag)
                                                showTagPicker = false
                                            }
                                            .background(if (state.emulatedTag?.id == tag.id) Accent.copy(alpha = 0.1f) else SurfaceElevated)
                                            .padding(horizontal = 12.dp, vertical = 10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    ) {
                                        Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(tagColor))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(tag.name, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                                            Text(tag.uid, fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = TextSecondary)
                                        }
                                        if (state.emulatedTag?.id == tag.id) {
                                            Icon(Icons.Filled.CheckCircle, null, tint = Accent, modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            ModeCard(
                title = "Emulate NFC Reader",
                description = "Your device acts as an NFC scanner/reader. Detects and logs nearby tags and cards.",
                icon = Icons.Outlined.SettingsInputAntenna,
                color = Success,
                isActive = state.mode == EmulatorMode.READER,
                onToggle = {
                    viewModel.setEmulatorMode(
                        if (state.mode == EmulatorMode.READER) EmulatorMode.OFF else EmulatorMode.READER
                    )
                },
            )

            if (isActive) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Surface)
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Icon(Icons.Outlined.Info, null, tint = TextMuted, modifier = Modifier.size(14.dp))
                    Text(
                        if (state.mode == EmulatorMode.TAG) "HCE (Host Card Emulation) is used for tag emulation. Some older readers may not detect software-emulated tags."
                        else "Reader mode will detect all nearby NFC tags.",
                        fontSize = 12.sp,
                        color = TextMuted,
                        modifier = Modifier.weight(1f),
                    )
                }
            }

            Spacer(Modifier.height(80.dp))
        }
    }
}

@Composable
private fun ModeCard(
    title: String,
    description: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: androidx.compose.ui.graphics.Color,
    isActive: Boolean,
    onToggle: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(if (isActive) SurfaceElevated else Surface)
            .clickable(onClick = onToggle)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(color.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, null, tint = color, modifier = Modifier.size(24.dp))
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = if (isActive) color else TextPrimary)
            Text(description, fontSize = 12.sp, color = TextMuted, lineHeight = 16.sp)
        }
        Switch(
            checked = isActive,
            onCheckedChange = { onToggle() },
            colors = SwitchDefaults.colors(
                checkedThumbColor = color,
                checkedTrackColor = color.copy(alpha = 0.3f),
                uncheckedThumbColor = TextMuted,
                uncheckedTrackColor = SurfaceBorder,
            ),
        )
    }
}

@Composable
private fun PulsingDot(color: androidx.compose.ui.graphics.Color) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(600), RepeatMode.Reverse),
        label = "alpha",
    )
    Box(
        modifier = Modifier
            .size(8.dp)
            .clip(CircleShape)
            .background(color.copy(alpha = alpha))
    )
}

@Composable
private fun SignalBar(height: androidx.compose.ui.unit.Dp, isActive: Boolean, color: androidx.compose.ui.graphics.Color, delayMs: Int) {
    val infiniteTransition = rememberInfiniteTransition(label = "signal")
    val alpha by infiniteTransition.animateFloat(
        initialValue = if (isActive) 0.3f else 0.2f,
        targetValue = if (isActive) 1f else 0.2f,
        animationSpec = infiniteRepeatable(tween(400, delayMillis = delayMs, easing = LinearEasing), RepeatMode.Reverse),
        label = "bar",
    )
    Box(
        modifier = Modifier
            .width(6.dp)
            .height(height)
            .clip(RoundedCornerShape(3.dp))
            .background(color.copy(alpha = alpha))
    )
}
