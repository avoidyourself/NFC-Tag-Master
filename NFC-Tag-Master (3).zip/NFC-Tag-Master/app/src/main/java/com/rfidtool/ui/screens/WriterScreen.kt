package com.rfidtool.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.outlined.FlashOn
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.KeyboardArrowUp
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rfidtool.data.NfcTagEntity
import com.rfidtool.ui.components.ScanAnimation
import com.rfidtool.ui.theme.*
import com.rfidtool.viewmodel.MainViewModel
import com.rfidtool.viewmodel.WriteMode
import com.rfidtool.viewmodel.WriteState

@Composable
fun WriterScreen(viewModel: MainViewModel) {
    val state by viewModel.writerState.collectAsState()
    val savedTags by viewModel.savedTags.collectAsState()
    val scrollState = rememberScrollState()
    var showTagPicker by remember { mutableStateOf(false) }

    val ringColor = when (state.writeState) {
        WriteState.SUCCESS -> Success
        WriteState.ERROR -> Error
        else -> Purple
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Background),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column {
                Text("NFC WRITER", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = TextPrimary, letterSpacing = 3.sp)
                Text("Write & clone tags", fontSize = 13.sp, color = TextMuted)
            }
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(Purple.copy(alpha = 0.15f))
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text(
                    state.writeMode.name,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Purple,
                    letterSpacing = 2.sp,
                )
            }
        }

        HorizontalDivider(color = SurfaceBorder, thickness = 1.dp)

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                WriteModeButton("NDEF", Icons.Filled.TextFields, state.writeMode == WriteMode.NDEF) {
                    viewModel.updateWriteMode(WriteMode.NDEF)
                }
                WriteModeButton("RAW", Icons.Filled.Code, state.writeMode == WriteMode.RAW) {
                    viewModel.updateWriteMode(WriteMode.RAW)
                }
                WriteModeButton("CLONE", Icons.Filled.ContentCopy, state.writeMode == WriteMode.CLONE) {
                    viewModel.updateWriteMode(WriteMode.CLONE)
                }
                WriteModeButton("WIPE", Icons.Filled.DeleteSweep, state.writeMode == WriteMode.WIPE) {
                    viewModel.updateWriteMode(WriteMode.WIPE)
                }
            }

            Spacer(Modifier.height(16.dp))

            if (state.writeState == WriteState.IDLE || state.writeState == WriteState.ERROR) {
                when (state.writeMode) {
                    WriteMode.NDEF -> {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Surface)
                                .padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                        ) {
                            SectionLabel("LANGUAGE CODE")
                            OutlinedTextField(
                                value = state.ndefLang,
                                onValueChange = { viewModel.updateNdefLang(it) },
                                modifier = Modifier.fillMaxWidth(),
                                colors = fieldColors(),
                                shape = RoundedCornerShape(8.dp),
                                singleLine = true,
                            )
                            SectionLabel("TEXT PAYLOAD")
                            OutlinedTextField(
                                value = state.ndefText,
                                onValueChange = { viewModel.updateNdefText(it) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(120.dp),
                                colors = fieldColors(),
                                shape = RoundedCornerShape(8.dp),
                                placeholder = { Text("Enter text to write...", color = TextMuted) },
                            )
                        }
                    }
                    WriteMode.RAW -> {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Surface)
                                .padding(14.dp),
                        ) {
                            SectionLabel("HEX DATA")
                            OutlinedTextField(
                                value = state.rawHex,
                                onValueChange = { viewModel.updateRawHex(it) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(160.dp),
                                colors = fieldColors(),
                                shape = RoundedCornerShape(8.dp),
                                placeholder = { Text("00 FF A0 3C ...", color = TextMuted, fontFamily = FontFamily.Monospace) },
                                textStyle = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = TextPrimary),
                            )
                            Text("Enter hex bytes separated by spaces", fontSize = 11.sp, color = TextMuted, modifier = Modifier.padding(top = 6.dp))
                        }
                    }
                    WriteMode.CLONE -> {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Surface)
                                .padding(14.dp),
                        ) {
                            SectionLabel("SELECT SOURCE TAG")
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(SurfaceElevated)
                                    .clickable { showTagPicker = !showTagPicker }
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Text(
                                    state.selectedCloneTag?.name ?: "Choose a saved tag...",
                                    fontSize = 14.sp,
                                    color = TextPrimary,
                                )
                                Icon(
                                    if (showTagPicker) Icons.Outlined.KeyboardArrowUp else Icons.Outlined.KeyboardArrowDown,
                                    null, tint = TextMuted, modifier = Modifier.size(16.dp),
                                )
                            }
                            AnimatedVisibility(showTagPicker) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = 8.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(SurfaceElevated),
                                ) {
                                    if (savedTags.isEmpty()) {
                                        Text("No saved tags yet", fontSize = 13.sp, color = TextMuted, modifier = Modifier.padding(12.dp))
                                    } else {
                                        savedTags.take(6).forEach { tag ->
                                            TagPickerItem(
                                                tag = tag,
                                                isSelected = state.selectedCloneTag?.id == tag.id,
                                                onClick = {
                                                    viewModel.selectCloneTag(tag)
                                                    showTagPicker = false
                                                },
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                    WriteMode.WIPE -> {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Warning.copy(alpha = 0.08f))
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            Icon(Icons.Filled.Warning, null, tint = Warning, modifier = Modifier.size(20.dp))
                            Text(
                                "This will zero out all writable sectors on the target tag. This action cannot be undone.",
                                fontSize = 13.sp,
                                color = Warning,
                                modifier = Modifier.weight(1f),
                            )
                        }
                    }
                }

                if (state.writeState == WriteState.ERROR && state.resultMessage != null) {
                    Text(
                        state.resultMessage!!,
                        fontSize = 13.sp,
                        color = Error,
                        modifier = Modifier.padding(top = 8.dp),
                    )
                }

                Spacer(Modifier.height(16.dp))

                Button(
                    onClick = { viewModel.startWrite() },
                    colors = ButtonDefaults.buttonColors(containerColor = Purple),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                ) {
                    Icon(Icons.Outlined.FlashOn, null, modifier = Modifier.size(18.dp))
                    Text(
                        when (state.writeMode) {
                            WriteMode.CLONE -> "CLONE TO TAG"
                            WriteMode.WIPE -> "WIPE TAG"
                            else -> "WRITE TO TAG"
                        },
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp,
                        modifier = Modifier.padding(start = 8.dp),
                    )
                }
            } else {
                Spacer(Modifier.height(16.dp))

                ScanAnimation(
                    isScanning = state.writeState == WriteState.AWAITING_TAG || state.writeState == WriteState.WRITING,
                    isFound = state.writeState == WriteState.SUCCESS,
                    isError = state.writeState == WriteState.ERROR,
                    color = ringColor,
                )

                Spacer(Modifier.height(12.dp))

                Text(
                    when (state.writeState) {
                        WriteState.AWAITING_TAG -> "AWAITING TAG..."
                        WriteState.WRITING -> "WRITING DATA..."
                        WriteState.SUCCESS -> "WRITE COMPLETE"
                        WriteState.ERROR -> "WRITE FAILED"
                        else -> ""
                    },
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = ringColor,
                    letterSpacing = 3.sp,
                )

                if (state.writeState == WriteState.SUCCESS) {
                    Spacer(Modifier.height(12.dp))
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Surface)
                            .padding(16.dp),
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Filled.CheckCircle, null, tint = Success, modifier = Modifier.size(20.dp))
                            Text("Tag Written Successfully", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Success)
                        }
                        Text("Mode: ${state.writeMode.name}", fontSize = 13.sp, color = TextSecondary, modifier = Modifier.padding(top = 4.dp))
                    }
                }

                Spacer(Modifier.height(16.dp))

                OutlinedButton(
                    onClick = { viewModel.resetWriter() },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = TextSecondary),
                ) {
                    Icon(Icons.Outlined.Refresh, null, modifier = Modifier.size(16.dp))
                    Text("START OVER", fontWeight = FontWeight.Bold, letterSpacing = 2.sp, modifier = Modifier.padding(start = 6.dp))
                }
            }

            Spacer(Modifier.height(80.dp))
        }
    }
}

@Composable
private fun WriteModeButton(label: String, icon: ImageVector, isSelected: Boolean, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (isSelected) Purple.copy(alpha = 0.15f) else Surface)
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp, horizontal = 12.dp),
    ) {
        Icon(icon, null, tint = if (isSelected) Purple else TextMuted, modifier = Modifier.size(20.dp))
        Spacer(Modifier.height(4.dp))
        Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (isSelected) Purple else TextMuted, letterSpacing = 1.sp)
    }
}

@Composable
private fun TagPickerItem(tag: NfcTagEntity, isSelected: Boolean, onClick: () -> Unit) {
    val tagColor = TagColors.getOrElse(tag.colorIndex) { Accent }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .background(if (isSelected) Accent.copy(alpha = 0.1f) else SurfaceElevated)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Box(modifier = Modifier.size(8.dp).clip(RoundedCornerShape(4.dp)).background(tagColor))
        Column(modifier = Modifier.weight(1f)) {
            Text(tag.name, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
            Text(tag.uid, fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = TextSecondary)
        }
        if (isSelected) {
            Icon(Icons.Filled.CheckCircle, null, tint = Accent, modifier = Modifier.size(16.dp))
        }
    }
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Accent,
    unfocusedBorderColor = SurfaceBorder,
    focusedContainerColor = SurfaceElevated,
    unfocusedContainerColor = SurfaceElevated,
    cursorColor = Accent,
    focusedTextColor = TextPrimary,
    unfocusedTextColor = TextPrimary,
)
