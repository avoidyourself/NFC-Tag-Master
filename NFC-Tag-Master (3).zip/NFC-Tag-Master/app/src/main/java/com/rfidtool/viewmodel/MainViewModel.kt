package com.rfidtool.viewmodel

import android.app.Application
import android.nfc.Tag
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.rfidtool.data.AppDatabase
import com.rfidtool.data.NfcTagEntity
import com.rfidtool.nfc.HceService
import com.rfidtool.nfc.NfcManager
import com.rfidtool.nfc.ScannedTagData
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class ScanState { IDLE, SCANNING, FOUND, ERROR }
enum class WriteState { IDLE, AWAITING_TAG, WRITING, SUCCESS, ERROR }
enum class WriteMode { NDEF, RAW, CLONE, WIPE }
enum class EmulatorMode { OFF, TAG, READER }

data class ReaderUiState(
    val scanState: ScanState = ScanState.IDLE,
    val currentTag: ScannedTagData? = null,
    val currentEntity: NfcTagEntity? = null,
    val isSaved: Boolean = false,
    val errorMessage: String? = null,
)

data class WriterUiState(
    val writeState: WriteState = WriteState.IDLE,
    val writeMode: WriteMode = WriteMode.NDEF,
    val ndefText: String = "",
    val ndefLang: String = "en",
    val rawHex: String = "",
    val selectedCloneTag: NfcTagEntity? = null,
    val resultMessage: String? = null,
)

data class EmulatorUiState(
    val mode: EmulatorMode = EmulatorMode.OFF,
    val emulatedTag: NfcTagEntity? = null,
    val isServiceActive: Boolean = false,
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getDatabase(application)
    private val tagDao = db.tagDao()

    val savedTags: StateFlow<List<NfcTagEntity>> = tagDao.getAllTags()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    private val _readerState = MutableStateFlow(ReaderUiState())
    val readerState: StateFlow<ReaderUiState> = _readerState.asStateFlow()

    private val _writerState = MutableStateFlow(WriterUiState())
    val writerState: StateFlow<WriterUiState> = _writerState.asStateFlow()

    private val _emulatorState = MutableStateFlow(EmulatorUiState())
    val emulatorState: StateFlow<EmulatorUiState> = _emulatorState.asStateFlow()

    private var pendingTag: Tag? = null

    fun startScanning() {
        _readerState.value = ReaderUiState(scanState = ScanState.SCANNING)
    }

    fun stopScanning() {
        _readerState.value = _readerState.value.copy(scanState = ScanState.IDLE)
    }

    fun onTagDiscovered(tag: Tag) {
        viewModelScope.launch {
            try {
                val data = NfcManager.parseTag(tag)
                val entity = NfcManager.scannedDataToEntity(data)

                when {
                    _readerState.value.scanState == ScanState.SCANNING -> {
                        _readerState.value = ReaderUiState(
                            scanState = ScanState.FOUND,
                            currentTag = data,
                            currentEntity = entity,
                        )
                    }
                    _writerState.value.writeState == WriteState.AWAITING_TAG -> {
                        pendingTag = tag
                        performWrite(tag)
                    }
                }
            } catch (e: Exception) {
                _readerState.value = ReaderUiState(
                    scanState = ScanState.ERROR,
                    errorMessage = e.message ?: "Failed to read tag",
                )
            }
        }
    }

    fun saveCurrentTag() {
        val entity = _readerState.value.currentEntity ?: return
        viewModelScope.launch {
            tagDao.insertTag(entity)
            _readerState.value = _readerState.value.copy(isSaved = true)
        }
    }

    fun resetReader() {
        _readerState.value = ReaderUiState()
    }

    fun updateWriteMode(mode: WriteMode) {
        _writerState.value = _writerState.value.copy(writeMode = mode, writeState = WriteState.IDLE)
    }

    fun updateNdefText(text: String) {
        _writerState.value = _writerState.value.copy(ndefText = text)
    }

    fun updateNdefLang(lang: String) {
        _writerState.value = _writerState.value.copy(ndefLang = lang)
    }

    fun updateRawHex(hex: String) {
        _writerState.value = _writerState.value.copy(rawHex = hex)
    }

    fun selectCloneTag(tag: NfcTagEntity?) {
        _writerState.value = _writerState.value.copy(selectedCloneTag = tag)
    }

    fun startWrite() {
        _writerState.value = _writerState.value.copy(writeState = WriteState.AWAITING_TAG)
    }

    private fun performWrite(tag: Tag) {
        viewModelScope.launch {
            _writerState.value = _writerState.value.copy(writeState = WriteState.WRITING)
            try {
                val state = _writerState.value
                val success = when (state.writeMode) {
                    WriteMode.NDEF -> NfcManager.writeNdefText(tag, state.ndefText, state.ndefLang)
                    WriteMode.WIPE -> NfcManager.wipeTag(tag)
                    WriteMode.CLONE -> {
                        val cloneTag = state.selectedCloneTag
                        if (cloneTag?.ndefPayload != null) {
                            val parts = cloneTag.ndefPayload.split(":", limit = 2)
                            val lang = if (parts.size == 2) parts[0] else "en"
                            val text = if (parts.size == 2) parts[1] else cloneTag.ndefPayload
                            NfcManager.writeNdefText(tag, text, lang)
                        } else false
                    }
                    WriteMode.RAW -> false
                }
                _writerState.value = _writerState.value.copy(
                    writeState = if (success) WriteState.SUCCESS else WriteState.ERROR,
                    resultMessage = if (success) "Write completed" else "Write failed - tag may be locked or incompatible",
                )
            } catch (e: Exception) {
                _writerState.value = _writerState.value.copy(
                    writeState = WriteState.ERROR,
                    resultMessage = e.message ?: "Write failed",
                )
            }
        }
    }

    fun resetWriter() {
        _writerState.value = WriterUiState()
    }

    fun setEmulatorMode(mode: EmulatorMode) {
        _emulatorState.value = _emulatorState.value.copy(mode = mode)
        if (mode == EmulatorMode.TAG) {
            val tag = _emulatorState.value.emulatedTag
            if (tag != null) {
                val uidBytes = tag.uid.split(":").map { it.toInt(16).toByte() }.toByteArray()
                HceService.emulatedUid = uidBytes
                HceService.emulatedData = tag.ndefPayload?.toByteArray(Charsets.UTF_8)
            }
        } else if (mode == EmulatorMode.OFF) {
            HceService.emulatedUid = null
            HceService.emulatedData = null
        }
    }

    fun setEmulatedTag(tag: NfcTagEntity?) {
        _emulatorState.value = _emulatorState.value.copy(emulatedTag = tag)
        if (_emulatorState.value.mode == EmulatorMode.TAG && tag != null) {
            val uidBytes = tag.uid.split(":").map { it.toInt(16).toByte() }.toByteArray()
            HceService.emulatedUid = uidBytes
            HceService.emulatedData = tag.ndefPayload?.toByteArray(Charsets.UTF_8)
        }
    }

    fun deleteTag(id: String) {
        viewModelScope.launch {
            tagDao.deleteTagById(id)
        }
    }

    fun updateTagName(id: String, name: String) {
        viewModelScope.launch {
            val tag = tagDao.getTagById(id) ?: return@launch
            tagDao.updateTag(tag.copy(name = name))
        }
    }

    fun getTagById(id: String): NfcTagEntity? {
        return savedTags.value.find { it.id == id }
    }
}
